package com.example.pjr_ap4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // MARS BUTTON
        Button btnMars = (Button) findViewById(R.id.btnMars);

        btnMars.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                alertDialog.setTitle("Objectif Mars");
                alertDialog.setMessage("Voulez-vous choisir l'événement objectif Mars ?");

                alertDialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(MainActivity.this, Mars.class);
                        startActivity(intent);
                    }
                });

                alertDialog.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Pas de traitement particulier
                    }
                });

                // Afficher la boîte de dialogue
                alertDialog.show();
            }
        });



        // SOLAIRE BUTTON
        Button btnSolaire = (Button) findViewById(R.id.btnSolaire);

        btnSolaire.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                alertDialog.setTitle("Système Solaire");
                alertDialog.setMessage("Voulez-vous choisir l'événement Système Solaire?");

                alertDialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), btnSolaire.getText(), Toast.LENGTH_LONG).show();
                    }
                });

                alertDialog.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Pas de traitement particulier
                    }
                });
                // Afficher la boîte de dialogue
                alertDialog.show();
            }
        });

        // TECH BUTTON
        Button btnTech = (Button) findViewById(R.id.btnTech);

        btnTech.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                alertDialog.setTitle("Espace Technologie");
                alertDialog.setMessage("Voulez-vous choisir l'événement espace technologie ?");

                alertDialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), btnTech.getText(), Toast.LENGTH_LONG).show();
                    }
                });

                alertDialog.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Pas de traitement particulier
                    }
                });
                // Afficher la boîte de dialogue
                alertDialog.show();
            }
        });

        // HUMAIN BUTTON
        Button btnHumain = (Button) findViewById(R.id.btnHumain);

        btnHumain.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                alertDialog.setTitle("Humain dans l'espace");
                alertDialog.setMessage("Voulez-vous choisir l'événement humain dans l'espace ?");

                alertDialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), btnHumain.getText(), Toast.LENGTH_LONG).show();
                    }
                });

                alertDialog.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Pas de traitement particulier
                    }
                });
                // Afficher la boîte de dialogue
                alertDialog.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menugeneral, menu);
        return true;
    }

    //Activation des menus et sous menus
    public boolean onOptionsItemSelected(MenuItem item){

        Toast.makeText(this, item.getTitle(), Toast.LENGTH_LONG).show();
        switch (item.getItemId()){
            case R.id.menuRechercher:
                Log.i("LocDVD", "Menu:Rechercher une séance");
                return true;

            case R.id.menuMagasins:
                Log.i("LocDVD", "Menu:Tarif");
                return true;

            case R.id.menuPresentation:
                Log.i("LocDVD", "Menu:Présentation");
                return true;
        }
        return true;
    }
}